# YouTubeNotes
Firefox add-on that allows user to mark YouTube video times of interest and write notes about them.
